package com.example.expense_tracker_fgf

data class Expense(
    val id: Int = 0,
    val amount: Double,
    val category: String,
    val date: String
)
