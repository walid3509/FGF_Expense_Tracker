package com.example.expense_tracker_fgf

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class AddExpenseActivity : AppCompatActivity() {

    private lateinit var amountEditText: EditText
    private lateinit var categoryEditText: EditText
    private lateinit var saveExpenseButton: Button
    private val dbHelper = ExpenseDatabaseHelper(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_expense)

        amountEditText = findViewById(R.id.amountEditText)
        categoryEditText = findViewById(R.id.categoryEditText)
        saveExpenseButton = findViewById(R.id.saveExpenseButton)

        saveExpenseButton.setOnClickListener {
            saveExpense()
        }
    }

    private fun saveExpense() {
        val amountText = amountEditText.text.toString()
        val categoryText = categoryEditText.text.toString()

        // Validate inputs
        if (amountText.isEmpty() || categoryText.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            return
        }

        val amount = amountText.toDoubleOrNull()
        if (amount == null) {
            Toast.makeText(this, "Invalid amount", Toast.LENGTH_SHORT).show()
            return
        }

        // Get current date
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

        // Insert expense into database
        val db = dbHelper.writableDatabase
        db.execSQL("INSERT INTO expenses (amount, category, date) VALUES (?, ?, ?)", arrayOf(amount, categoryText, date))
        db.close()

        Toast.makeText(this, "Expense added!", Toast.LENGTH_SHORT).show()
        finish() // Close activity and return to main screen
    }
}